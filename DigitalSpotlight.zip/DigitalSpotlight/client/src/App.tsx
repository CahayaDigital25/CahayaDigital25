import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";

import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home-page";
import ArticlePage from "@/pages/article-page";
import CategoryPage from "@/pages/category-page";
import ContactPage from "@/pages/contact-page";
import LoginPage from "@/pages/admin/login-page";
import DashboardPage from "@/pages/admin/dashboard-page";
import UsersPage from "@/pages/admin/users-page"; // Added import for UsersPage

function Router() {
  return (
    <Switch>
      {/* Public routes */}
      <Route path="/" component={HomePage} />
      <Route path="/article/:id" component={ArticlePage} />
      <Route path="/category/:slug" component={CategoryPage} />
      <Route path="/contact" component={ContactPage} />

      {/* Handle old admin URL pattern for security */}
      <Route path="/admin/*">
        {() => {
          window.location.href = "/not-found";
          return null;
        }}
      </Route>

      {/* Hidden admin routes with secure URL pattern that's not visible in UI */}
      <Route path="/cd25-secure-admin-panel/login" component={LoginPage} />

      {/* Protected admin routes */}
      <ProtectedRoute path="/cd25-secure-admin-panel/dashboard" component={DashboardPage} admin />
      <ProtectedRoute path="/cd25-secure-admin-panel/articles" component={DashboardPage} admin />
      <ProtectedRoute path="/cd25-secure-admin-panel/articles/new" component={DashboardPage} admin />
      <ProtectedRoute path="/cd25-secure-admin-panel/articles/:id/edit" component={DashboardPage} admin />
      <ProtectedRoute path="/cd25-secure-admin-panel/categories" component={DashboardPage} admin />
      <ProtectedRoute path="/cd25-secure-admin-panel/users" component={DashboardPage} admin />
      <ProtectedRoute path="/cd25-secure-admin-panel/settings" component={DashboardPage} admin />
      <Route path="/admin/dashboard" component={DashboardPage} />
      <Route path="/admin/users" component={UsersPage} />


      {/* 404 route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
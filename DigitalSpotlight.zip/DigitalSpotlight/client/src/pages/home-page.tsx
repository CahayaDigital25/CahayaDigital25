import { FC, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ArticleWithCategory } from "@shared/schema";
import Header from "@/components/site/header";
import Footer from "@/components/site/footer";
import HeroSection from "@/components/site/hero-section";
import CategoryTabs from "@/components/site/category-tabs";
import ArticleCard from "@/components/site/article-card";
import Sidebar from "@/components/site/sidebar";
import CTASection from "@/components/site/cta-section";
import { Button } from "@/components/ui/button";
import { ChevronRight } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export const HomePage: FC = () => {
  const [visibleArticles, setVisibleArticles] = useState(3);
  
  const { data: articles, isLoading } = useQuery<ArticleWithCategory[]>({
    queryKey: ["/api/articles"],
  });
  
  const handleLoadMore = () => {
    setVisibleArticles((prev) => prev + 3);
  };
  
  const handleSearch = (query: string) => {
    // Here you would implement search functionality
    console.log("Searching for:", query);
  };
  
  return (
    <>
      <Header />
      
      <HeroSection />
      
      <CategoryTabs />
      
      <main className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Main articles section */}
            <div className="lg:w-2/3">
              <h2 className="text-2xl font-montserrat font-bold mb-6">Berita Terbaru</h2>
              
              {isLoading ? (
                // Skeleton loading state
                Array.from({ length: 3 }).map((_, index) => (
                  <div key={index} className="mb-8">
                    <div className="md:flex">
                      <Skeleton className="md:w-48 h-48 rounded-xl" />
                      <div className="p-6 w-full">
                        <Skeleton className="h-8 w-3/4 mb-4" />
                        <Skeleton className="h-4 w-full mb-2" />
                        <Skeleton className="h-4 w-full mb-2" />
                        <Skeleton className="h-4 w-3/4 mb-4" />
                        <Skeleton className="h-4 w-40" />
                      </div>
                    </div>
                  </div>
                ))
              ) : articles?.length === 0 ? (
                <p className="text-center py-12 text-gray-500">
                  Belum ada artikel yang tersedia.
                </p>
              ) : (
                <>
                  {articles?.slice(0, visibleArticles).map((article) => (
                    <ArticleCard key={article.id} article={article} />
                  ))}
                  
                  {articles && visibleArticles < articles.length && (
                    <div className="flex justify-center mt-8">
                      <Button 
                        onClick={handleLoadMore} 
                        className="px-6 py-3 bg-primary text-white rounded-full"
                      >
                        Lihat Lebih Banyak
                        <ChevronRight className="ml-2 h-4 w-4" />
                      </Button>
                    </div>
                  )}
                </>
              )}
            </div>
            
            {/* Sidebar content */}
            <div className="lg:w-1/3">
              <Sidebar onSearch={handleSearch} />
            </div>
          </div>
        </div>
      </main>
      
      <CTASection />
      
      <Footer />
    </>
  );
};

export default HomePage;

import { FC, useState } from "react";
import { Switch, Route, Link } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Category, InsertCategory, User, Article } from "@shared/schema";
import DashboardSidebar from "@/components/admin/dashboard-sidebar";
import ArticleList from "@/components/admin/article-list";
import ArticleForm from "@/components/admin/article-form";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch as SwitchUI } from "@/components/ui/switch";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "@/components/ui/dialog";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle
} from "@/components/ui/card";
import {
  Form,
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormDescription,
  FormMessage
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { 
  Trash, 
  Loader2, 
  UserPlus, 
  UserCircle, 
  UserX,
  Plus,
  Edit,
  Trash2
} from "lucide-react";
import { format } from "date-fns";

export const DashboardPage: FC = () => {
  return (
    <div className="flex h-screen">
      <DashboardSidebar />
      
      <main className="flex-1 overflow-y-auto p-8">
        <Switch>
          <Route path="/cd25-secure-admin-panel/dashboard" component={AdminDashboard} />
          <Route path="/cd25-secure-admin-panel/articles" component={ArticleList} />
          <Route path="/cd25-secure-admin-panel/articles/new" component={() => <ArticleForm />} />
          <Route path="/cd25-secure-admin-panel/articles/:id/edit" component={EditArticlePage} />
          <Route path="/cd25-secure-admin-panel/categories" component={CategoriesPage} />
          <Route path="/cd25-secure-admin-panel/users" component={UsersPage} />
          <Route path="/cd25-secure-admin-panel/settings" component={SettingsPage} />
        </Switch>
      </main>
    </div>
  );
};

const AdminDashboard: FC = () => {
  const { data: articles, isLoading: isArticlesLoading } = useQuery<Article[]>({
    queryKey: ["/api/articles"],
  });
  
  const { data: categories, isLoading: isCategoriesLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  const isLoading = isArticlesLoading || isCategoriesLoading;
  
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Dashboard</h1>
      <p className="text-gray-600 mb-8">
        Selamat datang di panel admin CahayaDigital25. Gunakan menu navigasi untuk mengelola konten website.
      </p>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <h2 className="text-xl font-semibold mb-2">Artikel</h2>
          {isLoading ? (
            <Skeleton className="h-10 w-12" />
          ) : (
            <p className="text-3xl font-bold text-primary">{articles?.length || 0}</p>
          )}
          <p className="text-sm text-gray-500 mt-2">Total artikel yang dipublikasikan</p>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <h2 className="text-xl font-semibold mb-2">Kategori</h2>
          {isLoading ? (
            <Skeleton className="h-10 w-12" />
          ) : (
            <p className="text-3xl font-bold text-secondary">{categories?.length || 0}</p>
          )}
          <p className="text-sm text-gray-500 mt-2">Kategori yang tersedia</p>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <h2 className="text-xl font-semibold mb-2">Pengguna</h2>
          <p className="text-3xl font-bold text-accent">1</p>
          <p className="text-sm text-gray-500 mt-2">Admin yang terdaftar</p>
        </div>
      </div>
      
      <div className="mt-8">
        <h2 className="text-xl font-semibold mb-4">Aktivitas Terbaru</h2>
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          {isLoading ? (
            <div className="space-y-2">
              <Skeleton className="h-5 w-full" />
              <Skeleton className="h-5 w-3/4" />
              <Skeleton className="h-5 w-4/5" />
            </div>
          ) : articles && articles.length > 0 ? (
            <div className="space-y-4">
              {articles.slice(0, 3).map((article) => (
                <div key={article.id} className="flex items-center space-x-4 pb-4 border-b last:border-0">
                  <div className="flex-1">
                    <h3 className="font-medium">{article.title}</h3>
                    <p className="text-sm text-gray-500">
                      {format(new Date(article.publishedAt), "dd MMM yyyy")}
                    </p>
                  </div>
                  <Link 
                    href={`/cd25-secure-admin-panel/articles/${article.id}/edit`}
                    className="text-primary hover:underline text-sm"
                  >
                    Edit
                  </Link>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center py-8 text-gray-500">
              Belum ada artikel terbaru. Buat artikel baru untuk melihat aktivitas di sini.
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

const EditArticlePage: FC<{ params: { id: string } }> = ({ params }) => {
  const articleId = parseInt(params.id);
  return <ArticleForm articleId={articleId} />;
};

const CategoriesPage: FC = () => {
  const { toast } = useToast();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  
  const { data: categories, isLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  const addCategoryMutation = useMutation({
    mutationFn: async (data: InsertCategory) => {
      const res = await apiRequest("POST", "/api/admin/categories", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Kategori berhasil ditambahkan",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
      form.reset();
      setIsAddDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Gagal menambahkan kategori",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const updateCategoryMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: Partial<InsertCategory> }) => {
      const res = await apiRequest("PUT", `/api/admin/categories/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Kategori berhasil diperbarui",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
      editForm.reset();
      setIsEditDialogOpen(false);
      setEditingCategory(null);
    },
    onError: (error) => {
      toast({
        title: "Gagal memperbarui kategori",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const deleteCategoryMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/admin/categories/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Kategori berhasil dihapus",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
    },
    onError: (error) => {
      toast({
        title: "Gagal menghapus kategori",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const formSchema = z.object({
    name: z.string().min(2, "Nama harus memiliki minimal 2 karakter"),
    slug: z.string().min(2, "Slug harus memiliki minimal 2 karakter")
      .regex(/^[a-z0-9-]+$/, "Slug hanya boleh berisi huruf kecil, angka, dan tanda hubung"),
  });
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      slug: "",
    },
  });
  
  const editForm = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      slug: "",
    },
  });
  
  const onAddSubmit = (data: z.infer<typeof formSchema>) => {
    addCategoryMutation.mutate(data);
  };
  
  const onEditSubmit = (data: z.infer<typeof formSchema>) => {
    if (editingCategory) {
      updateCategoryMutation.mutate({ id: editingCategory.id, data });
    }
  };
  
  const handleEditClick = (category: Category) => {
    setEditingCategory(category);
    editForm.reset({
      name: category.name,
      slug: category.slug,
    });
    setIsEditDialogOpen(true);
  };
  
  const handleDeleteClick = (id: number) => {
    if (confirm("Apakah Anda yakin ingin menghapus kategori ini? Semua artikel di kategori ini juga akan terhapus.")) {
      deleteCategoryMutation.mutate(id);
    }
  };
  
  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Skeleton className="h-10 w-48" />
          <Skeleton className="h-10 w-32" />
        </div>
        <div className="rounded-md border">
          <div className="h-12 px-4 border-b flex items-center">
            <Skeleton className="h-4 w-full" />
          </div>
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-16 px-4 border-b flex items-center">
              <Skeleton className="h-4 w-full" />
            </div>
          ))}
        </div>
      </div>
    );
  }
  
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Kategori</h1>
        <Button onClick={() => setIsAddDialogOpen(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Tambah Kategori
        </Button>
      </div>
      
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ID</TableHead>
              <TableHead>Nama</TableHead>
              <TableHead>Slug</TableHead>
              <TableHead className="text-right">Aksi</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {categories?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={4} className="text-center py-8">
                  Belum ada kategori. Klik "Tambah Kategori" untuk memulai.
                </TableCell>
              </TableRow>
            ) : (
              categories?.map((category) => (
                <TableRow key={category.id}>
                  <TableCell>{category.id}</TableCell>
                  <TableCell className="font-medium">{category.name}</TableCell>
                  <TableCell>{category.slug}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end space-x-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => handleEditClick(category)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button 
                        size="sm" 
                        variant="destructive"
                        onClick={() => handleDeleteClick(category.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
      
      {/* Dialog Tambah Kategori */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Tambah Kategori Baru</DialogTitle>
            <DialogDescription>
              Kategori akan digunakan untuk mengelompokkan artikel.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onAddSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nama Kategori</FormLabel>
                    <FormControl>
                      <Input placeholder="Teknologi" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="slug"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Slug</FormLabel>
                    <FormControl>
                      <Input placeholder="teknologi" {...field} />
                    </FormControl>
                    <FormDescription>
                      Slug akan digunakan untuk URL. Gunakan huruf kecil, angka, dan tanda hubung.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsAddDialogOpen(false)}
                >
                  Batal
                </Button>
                <Button type="submit" disabled={addCategoryMutation.isPending}>
                  {addCategoryMutation.isPending ? (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  ) : null}
                  Simpan
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      {/* Dialog Edit Kategori */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Kategori</DialogTitle>
            <DialogDescription>
              Ubah informasi kategori.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-4">
              <FormField
                control={editForm.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nama Kategori</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={editForm.control}
                name="slug"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Slug</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormDescription>
                      Slug akan digunakan untuk URL. Gunakan huruf kecil, angka, dan tanda hubung.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => {
                    setIsEditDialogOpen(false);
                    setEditingCategory(null);
                  }}
                >
                  Batal
                </Button>
                <Button type="submit" disabled={updateCategoryMutation.isPending}>
                  {updateCategoryMutation.isPending ? (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  ) : null}
                  Perbarui
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

const UsersPage: FC = () => {
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  // Mendapatkan daftar pengguna dari server
  const { data: users, isLoading } = useQuery<User[]>({
    queryKey: ["/api/admin/users"],
  });
  
  // Mendefinisikan form schema untuk penambahan admin/moderator baru
  const formSchema = z.object({
    username: z.string().min(3, "Username harus memiliki minimal 3 karakter"),
    password: z.string().min(6, "Password harus memiliki minimal 6 karakter"),
    isAdmin: z.boolean().default(true),
  });
  
  // Type untuk form
  type UserFormValues = z.infer<typeof formSchema>;
  
  // Setup form dengan react-hook-form
  const form = useForm<UserFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      username: "",
      password: "",
      isAdmin: true,
    },
  });
  
  // Mutation untuk membuat user baru
  const createUserMutation = useMutation({
    mutationFn: async (data: UserFormValues) => {
      const res = await apiRequest("POST", "/api/admin/users", data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Admin/Moderator berhasil dibuat",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      form.reset();
      setIsDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Gagal membuat admin/moderator",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Mutation untuk menghapus user
  const deleteUserMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/admin/users/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Pengguna berhasil dihapus",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
    },
    onError: (error) => {
      toast({
        title: "Gagal menghapus pengguna",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Handler untuk form submission
  const onSubmit = (data: UserFormValues) => {
    createUserMutation.mutate(data);
  };
  
  // Handler untuk menghapus user
  const handleDeleteUser = (id: number) => {
    if (window.confirm("Apakah Anda yakin ingin menghapus pengguna ini?")) {
      deleteUserMutation.mutate(id);
    }
  };
  
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Pengguna</h1>
        <Button onClick={() => setIsDialogOpen(true)}>
          <UserPlus className="mr-2 h-4 w-4" />
          Tambah Admin/Moderator
        </Button>
      </div>
      
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-32 w-full" />
          ))}
        </div>
      ) : users && users.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {users.map((user) => (
            <Card key={user.id} className="relative">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <UserCircle className="h-6 w-6 mr-2 text-primary" />
                  {user.username}
                </CardTitle>
                <Button
                  variant="destructive"
                  size="icon"
                  className="absolute top-3 right-3"
                  onClick={() => handleDeleteUser(user.id)}
                  disabled={deleteUserMutation.isPending}
                >
                  <Trash className="h-4 w-4" />
                </Button>
              </CardHeader>
              <CardContent>
                <Badge variant={user.isAdmin ? "default" : "outline"}>
                  {user.isAdmin ? "Admin" : "Moderator"}
                </Badge>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 bg-muted/40 rounded-lg">
          <UserX className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <p className="text-lg font-medium text-muted-foreground">
            Belum ada admin atau moderator tambahan
          </p>
          <Button
            variant="secondary"
            className="mt-4"
            onClick={() => setIsDialogOpen(true)}
          >
            Tambah Admin/Moderator
          </Button>
        </div>
      )}
      
      {/* Dialog untuk menambahkan admin/moderator baru */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Tambah Admin/Moderator Baru</DialogTitle>
            <DialogDescription>
              Tambahkan admin atau moderator baru untuk mengelola konten website.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Username</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormDescription>
                      Username untuk login ke dashboard admin.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Password</FormLabel>
                    <FormControl>
                      <Input type="password" {...field} />
                    </FormControl>
                    <FormDescription>
                      Password harus memiliki minimal 6 karakter.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="isAdmin"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                    <div className="space-y-0.5">
                      <FormLabel>Hak Akses Admin</FormLabel>
                      <FormDescription>
                        Berikan hak akses admin penuh pada pengguna ini
                      </FormDescription>
                    </div>
                    <FormControl>
                      <SwitchUI
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button type="submit" disabled={createUserMutation.isPending}>
                  {createUserMutation.isPending ? (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  ) : null}
                  Tambah Pengguna
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

const SettingsPage: FC = () => {
  return (
    <div>
      <h1 className="text-3xl font-bold">Pengaturan</h1>
      <p className="text-gray-600 mt-2">
        Halaman ini masih dalam pengembangan. Segera hadir!
      </p>
    </div>
  );
};

export default DashboardPage;
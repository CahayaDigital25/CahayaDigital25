import { FC, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { ArticleWithCategory, Category } from "@shared/schema";
import Header from "@/components/site/header";
import Footer from "@/components/site/footer";
import CategoryTabs from "@/components/site/category-tabs";
import ArticleCard from "@/components/site/article-card";
import Sidebar from "@/components/site/sidebar";
import { Button } from "@/components/ui/button";
import { ChevronRight } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export const CategoryPage: FC = () => {
  const [, params] = useRoute("/category/:slug");
  const categorySlug = params?.slug || "";
  const [visibleArticles, setVisibleArticles] = useState(5);
  
  const { data: category, isLoading: isCategoryLoading } = useQuery<Category>({
    queryKey: ["/api/categories", categorySlug],
    enabled: !!categorySlug,
  });
  
  const { data: articles, isLoading: isArticlesLoading } = useQuery<ArticleWithCategory[]>({
    queryKey: ["/api/articles", { categoryId: category?.id }],
    enabled: !!category?.id,
  });
  
  const isLoading = isCategoryLoading || isArticlesLoading;
  
  const handleLoadMore = () => {
    setVisibleArticles((prev) => prev + 5);
  };
  
  return (
    <>
      <Header />
      
      <CategoryTabs selectedCategory={categorySlug} />
      
      <main className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-montserrat font-bold mb-6">
            {isLoading ? (
              <Skeleton className="h-9 w-48" />
            ) : (
              `Kategori: ${category?.name || ""}`
            )}
          </h1>
          
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Main articles section */}
            <div className="lg:w-2/3">
              {isLoading ? (
                // Skeleton loading state
                Array.from({ length: 3 }).map((_, index) => (
                  <div key={index} className="mb-8">
                    <div className="md:flex">
                      <Skeleton className="md:w-48 h-48 rounded-xl" />
                      <div className="p-6 w-full">
                        <Skeleton className="h-8 w-3/4 mb-4" />
                        <Skeleton className="h-4 w-full mb-2" />
                        <Skeleton className="h-4 w-full mb-2" />
                        <Skeleton className="h-4 w-3/4 mb-4" />
                        <Skeleton className="h-4 w-40" />
                      </div>
                    </div>
                  </div>
                ))
              ) : articles?.length === 0 ? (
                <div className="text-center py-12 bg-white rounded-xl shadow-sm">
                  <h3 className="text-xl font-semibold mb-2">Belum ada artikel</h3>
                  <p className="text-gray-600">
                    Belum ada artikel yang tersedia untuk kategori ini.
                  </p>
                </div>
              ) : (
                <>
                  {articles?.slice(0, visibleArticles).map((article) => (
                    <ArticleCard key={article.id} article={article} />
                  ))}
                  
                  {articles && visibleArticles < articles.length && (
                    <div className="flex justify-center mt-8">
                      <Button 
                        onClick={handleLoadMore} 
                        className="px-6 py-3 bg-primary text-white rounded-full"
                      >
                        Lihat Lebih Banyak
                        <ChevronRight className="ml-2 h-4 w-4" />
                      </Button>
                    </div>
                  )}
                </>
              )}
            </div>
            
            {/* Sidebar content */}
            <div className="lg:w-1/3">
              <Sidebar />
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </>
  );
};

export default CategoryPage;

import { FC } from "react";
import Header from "@/components/site/header";
import Footer from "@/components/site/footer";
import ContactForm from "@/components/site/contact-form";

export const ContactPage: FC = () => {
  return (
    <>
      <Header />
      <ContactForm />
      <Footer />
    </>
  );
};

export default ContactPage;


import { FC } from "react";
import { useRoute } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import id from "date-fns/locale/id";
import { ArticleWithCategory } from "@shared/schema";
import Header from "@/components/site/header";
import Footer from "@/components/site/footer";
import Sidebar from "@/components/site/sidebar";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Calendar, Clock } from "lucide-react";

const ArticlePage: FC = () => {
  const [, params] = useRoute("/article/:id");
  const articleId = params?.id ? parseInt(params.id) : 0;

  const { data: article, isLoading, isError } = useQuery<ArticleWithCategory>({
    queryKey: ["/api/articles", articleId],
    queryFn: async () => {
      const response = await fetch(`/api/articles/${articleId}`);
      if (!response.ok) {
        throw new Error("Failed to fetch article");
      }
      return response.json();
    },
    enabled: !!articleId,
  });

  if (isLoading) {
    return (
      <>
        <Header />
        <main className="py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col lg:flex-row gap-8">
              <div className="lg:w-2/3">
                <Skeleton className="h-64 w-full rounded-xl mb-6" />
                <Skeleton className="h-8 w-3/4 mb-4" />
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-3/4" />
              </div>
              <div className="lg:w-1/3">
                <Sidebar />
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </>
    );
  }

  if (isError || !article) {
    return (
      <>
        <Header />
        <main className="py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-2xl font-bold text-gray-900">Artikel tidak ditemukan</h1>
            </div>
          </div>
        </main>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Header />
      <main className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row gap-8">
            <article className="lg:w-2/3">
              <img 
                src={article.imageUrl} 
                alt={article.title}
                className="w-full h-64 object-cover rounded-xl mb-6"
              />
              <h1 className="text-3xl font-bold text-gray-900 mb-4">{article.title}</h1>
              <div className="flex items-center gap-2 mb-4">
                {article.category && (
                  <Badge variant="secondary">{article.category.name}</Badge>
                )}
              </div>
              <div className="flex items-center text-sm text-gray-500 mb-6">
                <Calendar className="h-4 w-4 mr-1" />
                <span>{article.publishedAt ? format(new Date(article.publishedAt), 'dd MMMM yyyy', { locale: id }) : '-'}</span>
                <span className="mx-2">•</span>
                <Clock className="h-4 w-4 mr-1" />
                <span>{article.readTime} menit membaca</span>
              </div>
              <div className="prose max-w-none">
                <p className="text-gray-600 mb-6 leading-relaxed">{article.summary}</p>
                <div 
                  className="leading-relaxed"
                  dangerouslySetInnerHTML={{ __html: article.content }}
                />
              </div>
            </article>
            <div className="lg:w-1/3">
              <Sidebar />
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
};

export default ArticlePage;

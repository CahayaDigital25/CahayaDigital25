import { FC, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertArticleSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Category } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";
import { useLocation } from "wouter";

interface ArticleFormProps {
  articleId?: number;
}

// Gunakan schema yang sudah didefinisikan dari shared/schema
const formSchema = insertArticleSchema;

export const ArticleForm: FC<ArticleFormProps> = ({ articleId }) => {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const isEditing = !!articleId;

  const { data: categories, isLoading: isCategoriesLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: article, isLoading: isArticleLoading } = useQuery({
    queryKey: ["/api/articles", articleId],
    enabled: isEditing,
  });

  const createArticleMutation = useMutation({
    mutationFn: async (data: z.infer<typeof formSchema>) => {
      const res = await apiRequest("POST", "/api/admin/articles", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Article created successfully",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/articles"] });
      navigate("/cd25-secure-admin-panel/dashboard");
    },
    onError: (error) => {
      toast({
        title: "Failed to create article",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateArticleMutation = useMutation({
    mutationFn: async (data: z.infer<typeof formSchema>) => {
      const res = await apiRequest("PUT", `/api/admin/articles/${articleId}`, data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Article updated successfully",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/articles"] });
      navigate("/cd25-secure-admin-panel/dashboard");
    },
    onError: (error) => {
      toast({
        title: "Failed to update article",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: article?.title || "",
      content: article?.content || "",
      summary: article?.summary || "",
      imageUrl: article?.imageUrl || "",
      categoryId: article?.categoryId || 0,
      publishedAt: article?.publishedAt ? new Date(article.publishedAt) : new Date(),
      readTime: article?.readTime || 5,
      featured: article?.featured || false,
    },
    values: article ? {
      ...article,
      publishedAt: new Date(article.publishedAt),
    } : undefined,
  });

  const onSubmit = (data: z.infer<typeof formSchema>) => {
    // Format data untuk memastikan format yang benar
    const formattedData = {
      ...data,
      // Pastikan tanggal dalam format string (ISO)
      publishedAt: data.publishedAt instanceof Date 
        ? data.publishedAt.toISOString() 
        : new Date(data.publishedAt).toISOString(),
      // Pastikan categoryId adalah angka
      categoryId: Number(data.categoryId),
      // Pastikan readTime adalah angka
      readTime: Number(data.readTime),
      // Pastikan featured adalah boolean
      featured: Boolean(data.featured)
    };

    console.log("Submitting form data:", formattedData);

    if (isEditing) {
      updateArticleMutation.mutate(formattedData);
    } else {
      createArticleMutation.mutate(formattedData);
    }
  };

  const isLoading = isArticleLoading || isCategoriesLoading;
  const isSubmitting = createArticleMutation.isPending || updateArticleMutation.isPending;

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Judul Artikel</FormLabel>
              <FormControl>
                <Input placeholder="Masukkan judul artikel..." {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="summary"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Ringkasan</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Ringkasan singkat artikel..." 
                  className="resize-none h-20"
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="content"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Konten</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Konten artikel lengkap..." 
                  className="resize-none h-60"
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            control={form.control}
            name="imageUrl"
            render={({ field }) => (
              <FormItem>
                <FormLabel>URL Gambar</FormLabel>
                <FormControl>
                  <Input placeholder="https://example.com/image.jpg" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="categoryId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Kategori</FormLabel>
                <Select 
                  onValueChange={field.onChange} 
                  defaultValue={field.value.toString()}
                  value={field.value.toString()}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih kategori" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {categories?.map((category) => (
                      <SelectItem key={category.id} value={category.id.toString()}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            control={form.control}
            name="publishedAt"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Tanggal Publikasi</FormLabel>
                <FormControl>
                  <Input 
                    type="date" 
                    {...field}
                    value={field.value instanceof Date && !isNaN(field.value.getTime())
                      ? field.value.toISOString().split('T')[0]
                      : new Date().toISOString().split('T')[0]
                    }
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="readTime"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Waktu Baca (menit)</FormLabel>
                <FormControl>
                  <Input type="number" min="1" max="60" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="featured"
          render={({ field }) => (
            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
              <div className="space-y-0.5">
                <FormLabel className="text-base">Featured Article</FormLabel>
                <p className="text-sm text-muted-foreground">
                  Tampilkan artikel ini di bagian utama homepage
                </p>
              </div>
              <FormControl>
                <Switch
                  checked={field.value}
                  onCheckedChange={field.onChange}
                />
              </FormControl>
            </FormItem>
          )}
        />

        <div className="flex justify-end space-x-4">
          <Button 
            type="button" 
            variant="outline"
            onClick={() => navigate("/cd25-secure-admin-panel/dashboard")}
            disabled={isSubmitting}
          >
            Batal
          </Button>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {isEditing ? "Update Artikel" : "Publikasikan Artikel"}
          </Button>
        </div>
      </form>
    </Form>
  );
};

export default ArticleForm;
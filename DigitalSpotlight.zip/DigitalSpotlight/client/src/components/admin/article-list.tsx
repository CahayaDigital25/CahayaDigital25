import { FC, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { ArticleWithCategory } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Edit, Trash2 } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";

export const ArticleList: FC = () => {
  const { toast } = useToast();
  const [articleIdToDelete, setArticleIdToDelete] = useState<number | null>(null);
  
  const { data: articles, isLoading } = useQuery<ArticleWithCategory[]>({
    queryKey: ["/api/articles"],
  });
  
  const deleteArticleMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/admin/articles/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Article deleted successfully",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/articles"] });
    },
    onError: (error) => {
      toast({
        title: "Failed to delete article",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const handleConfirmDelete = () => {
    if (articleIdToDelete !== null) {
      deleteArticleMutation.mutate(articleIdToDelete);
      setArticleIdToDelete(null);
    }
  };
  
  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Skeleton className="h-10 w-32" />
          <Skeleton className="h-10 w-32" />
        </div>
        <div className="rounded-md border">
          <div className="h-12 px-4 border-b flex items-center">
            <Skeleton className="h-4 w-full" />
          </div>
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-16 px-4 border-b flex items-center">
              <Skeleton className="h-4 w-full" />
            </div>
          ))}
        </div>
      </div>
    );
  }
  
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Daftar Artikel</h2>
        <Link href="/cd25-secure-admin-panel/articles/new">
          <Button>Tambah Artikel</Button>
        </Link>
      </div>
      
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Judul</TableHead>
              <TableHead>Kategori</TableHead>
              <TableHead>Tanggal</TableHead>
              <TableHead>Featured</TableHead>
              <TableHead className="text-right">Aksi</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {articles?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-8">
                  Belum ada artikel. Klik "Tambah Artikel" untuk membuat artikel baru.
                </TableCell>
              </TableRow>
            ) : (
              articles?.map((article) => (
                <TableRow key={article.id}>
                  <TableCell className="font-medium max-w-md truncate">
                    {article.title}
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">{article.category?.name}</Badge>
                  </TableCell>
                  <TableCell>
                    {format(new Date(article.publishedAt), "dd MMM yyyy")}
                  </TableCell>
                  <TableCell>
                    {article.featured ? (
                      <Badge className="bg-primary">Featured</Badge>
                    ) : (
                      <Badge variant="outline">Regular</Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end space-x-2">
                      <Link href={`/cd25-secure-admin-panel/articles/${article.id}/edit`}>
                        <Button size="sm" variant="outline">
                          <Edit className="h-4 w-4" />
                        </Button>
                      </Link>
                      
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button 
                            size="sm" 
                            variant="destructive"
                            onClick={() => setArticleIdToDelete(article.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Konfirmasi Hapus</AlertDialogTitle>
                            <AlertDialogDescription>
                              Apakah Anda yakin ingin menghapus artikel "{article.title}"?
                              Tindakan ini tidak dapat dibatalkan.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel onClick={() => setArticleIdToDelete(null)}>
                              Batal
                            </AlertDialogCancel>
                            <AlertDialogAction 
                              onClick={handleConfirmDelete}
                              className="bg-destructive text-destructive-foreground"
                            >
                              {deleteArticleMutation.isPending ? (
                                <Loader2 className="h-4 w-4 animate-spin" />
                              ) : (
                                "Hapus"
                              )}
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default ArticleList;

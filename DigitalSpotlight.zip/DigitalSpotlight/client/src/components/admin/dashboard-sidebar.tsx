import { FC } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import Logo from "../site/logo";
import { 
  LayoutDashboard, 
  FileText, 
  Tag, 
  Users, 
  Settings, 
  LogOut, 
  ChevronRight
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";

interface NavItemProps {
  href: string;
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
}

const NavItem: FC<NavItemProps> = ({ href, icon, label, isActive }) => {
  return (
    <Link href={href}>
      <a className={`flex items-center gap-3 rounded-lg px-3 py-2 transition-all ${
        isActive 
          ? "bg-primary text-primary-foreground" 
          : "text-muted-foreground hover:bg-primary/10 hover:text-primary"
      }`}>
        {icon}
        <span>{label}</span>
        {isActive && <ChevronRight className="ml-auto h-4 w-4" />}
      </a>
    </Link>
  );
};

export const DashboardSidebar: FC = () => {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  
  const navItems = [
    {
      href: "/cd25-secure-admin-panel/dashboard",
      icon: <LayoutDashboard className="h-5 w-5" />,
      label: "Dashboard",
    },
    {
      href: "/cd25-secure-admin-panel/articles",
      icon: <FileText className="h-5 w-5" />,
      label: "Artikel",
    },
    {
      href: "/cd25-secure-admin-panel/categories",
      icon: <Tag className="h-5 w-5" />,
      label: "Kategori",
    },
    {
      href: "/cd25-secure-admin-panel/users",
      icon: <Users className="h-5 w-5" />,
      label: "Pengguna",
    },
    {
      href: "/cd25-secure-admin-panel/settings",
      icon: <Settings className="h-5 w-5" />,
      label: "Pengaturan",
    },
  ];
  
  return (
    <div className="flex h-screen flex-col border-r bg-muted/20">
      <div className="p-6">
        <Logo />
      </div>
      
      <Separator />
      
      <ScrollArea className="flex-1 px-4 py-6">
        <nav className="flex flex-col gap-2">
          {navItems.map((item) => (
            <NavItem 
              key={item.href}
              href={item.href}
              icon={item.icon}
              label={item.label}
              isActive={location === item.href}
            />
          ))}
        </nav>
      </ScrollArea>
      
      <div className="sticky bottom-0 mt-auto border-t bg-muted/20 p-4">
        <div className="flex items-center gap-3 rounded-lg p-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary">
            <span className="text-sm font-medium text-white">
              {user?.username.charAt(0).toUpperCase()}
            </span>
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-medium">{user?.username}</span>
            <span className="text-xs text-muted-foreground">Admin</span>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            className="ml-auto text-muted-foreground hover:text-destructive"
            onClick={() => logoutMutation.mutate()}
          >
            <LogOut className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default DashboardSidebar;

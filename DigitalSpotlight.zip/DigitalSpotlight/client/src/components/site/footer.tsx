import { FC } from "react";
import { Link } from "wouter";
import Logo from "./logo";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export const Footer: FC = () => {
  return (
    <footer className="bg-dark text-white pt-12 pb-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div className="md:col-span-1">
            <Logo textColor="text-white" />
            <p className="text-gray-400 mb-4 mt-4">
              Portal berita teknologi dan digital terkini dengan berbagai ulasan mendalam dan informasi terpercaya.
            </p>
            <div className="flex space-x-3">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <i className="fab fa-instagram"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <i className="fab fa-youtube"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-montserrat font-bold mb-4">Kategori</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/category/teknologi">
                  <a className="text-gray-400 hover:text-white transition-colors">Teknologi</a>
                </Link>
              </li>
              <li>
                <Link href="/category/gadget">
                  <a className="text-gray-400 hover:text-white transition-colors">Gadget</a>
                </Link>
              </li>
              <li>
                <Link href="/category/bisnis-digital">
                  <a className="text-gray-400 hover:text-white transition-colors">Bisnis Digital</a>
                </Link>
              </li>
              <li>
                <Link href="/category/game">
                  <a className="text-gray-400 hover:text-white transition-colors">Game</a>
                </Link>
              </li>
              <li>
                <Link href="/category/startup">
                  <a className="text-gray-400 hover:text-white transition-colors">Startup</a>
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-montserrat font-bold mb-4">Tautan</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/">
                  <a className="text-gray-400 hover:text-white transition-colors">Beranda</a>
                </Link>
              </li>
              <li>
                <Link href="/about">
                  <a className="text-gray-400 hover:text-white transition-colors">Tentang Kami</a>
                </Link>
              </li>
              <li>
                <Link href="/contact">
                  <a className="text-gray-400 hover:text-white transition-colors">Kontak</a>
                </Link>
              </li>
              <li>
                <Link href="/privacy">
                  <a className="text-gray-400 hover:text-white transition-colors">Kebijakan Privasi</a>
                </Link>
              </li>
              <li>
                <Link href="/terms">
                  <a className="text-gray-400 hover:text-white transition-colors">Syarat dan Ketentuan</a>
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-montserrat font-bold mb-4">Berlangganan</h3>
            <p className="text-gray-400 mb-4">Dapatkan berita teknologi terbaru langsung ke email Anda</p>
            <div className="flex">
              <Input 
                type="email" 
                placeholder="Email Anda" 
                className="rounded-l-lg focus:outline-none text-dark border-0"
              />
              <Button 
                type="button" 
                className="bg-primary hover:bg-primary/90 px-4 py-2 rounded-r-lg border-0"
              >
                <i className="fas fa-paper-plane"></i>
              </Button>
            </div>
          </div>
        </div>
        
        <div className="pt-8 mt-8 border-t border-gray-800 text-center">
          <p className="text-gray-400">© 2023 cahayadigital25. Seluruh hak cipta dilindungi.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

import { useState } from "react";
import { Link, useRoute } from "wouter";
import Logo from "./logo";
import { Search, User, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useAuth } from "@/hooks/use-auth";

const categoryLinks = [
  { name: "Teknologi", href: "/category/teknologi", icon: "laptop-code" },
  { name: "Gadget", href: "/category/gadget", icon: "mobile-alt" },
  { name: "Bisnis Digital", href: "/category/bisnis-digital", icon: "chart-line" },
  { name: "Game", href: "/category/game", icon: "gamepad" },
];

export const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isHome] = useRoute("/");
  const { user, logoutMutation } = useAuth();
  
  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header className="sticky top-0 z-50 bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4 md:justify-start md:space-x-10">
          {/* Logo */}
          <div className="flex justify-start lg:w-0 lg:flex-1">
            <Logo />
          </div>
          
          {/* Mobile menu button */}
          <div className="-mr-2 -my-2 md:hidden">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={toggleMenu}
              aria-expanded={isMenuOpen}
              aria-label="Toggle menu"
            >
              <span className="sr-only">Open menu</span>
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
          
          {/* Desktop navigation */}
          <nav className="hidden md:flex space-x-10">
            <Link href="/">
              <a className={`text-base font-medium ${isHome ? 'text-primary border-b-2 border-primary' : 'text-dark hover:text-primary'}`}>
                Beranda
              </a>
            </Link>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="link" className="text-base font-medium text-dark hover:text-primary">
                  Kategori <i className="fas fa-chevron-down ml-1 text-xs"></i>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                {categoryLinks.map((category) => (
                  <DropdownMenuItem key={category.href} asChild>
                    <Link href={category.href}>
                      <a className="flex items-center">
                        <i className={`fas fa-${category.icon} text-primary mr-2`}></i>
                        {category.name}
                      </a>
                    </Link>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
            
            <Link href="/latest">
              <a className="text-base font-medium text-dark hover:text-primary">
                Terbaru
              </a>
            </Link>
            
            <Link href="/trending">
              <a className="text-base font-medium text-dark hover:text-primary">
                Trending
              </a>
            </Link>
            
            <Link href="/contact">
              <a className="text-base font-medium text-dark hover:text-primary">
                Kontak
              </a>
            </Link>
          </nav>
          
          <div className="hidden md:flex items-center justify-end md:flex-1 lg:w-0">
            <Button variant="ghost" size="icon" className="ml-8">
              <Search className="h-5 w-5" />
            </Button>
            
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="ml-6">
                    <User className="h-5 w-5 mr-1" />
                    {user.username}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  {user.isAdmin && (
                    <DropdownMenuItem asChild>
                      <Link href="/cd25-secure-admin-panel/dashboard">
                        <a>Dashboard</a>
                      </Link>
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem onClick={() => logoutMutation.mutate()}>
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : null}
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <Link href="/">
              <a className="block px-3 py-2 rounded-md text-base font-medium text-primary bg-gray-50">
                Beranda
              </a>
            </Link>
            
            {categoryLinks.map((category) => (
              <Link key={category.href} href={category.href}>
                <a className="block px-3 py-2 rounded-md text-base font-medium text-dark hover:text-primary hover:bg-gray-50">
                  {category.name}
                </a>
              </Link>
            ))}
            
            <Link href="/latest">
              <a className="block px-3 py-2 rounded-md text-base font-medium text-dark hover:text-primary hover:bg-gray-50">
                Terbaru
              </a>
            </Link>
            
            <Link href="/trending">
              <a className="block px-3 py-2 rounded-md text-base font-medium text-dark hover:text-primary hover:bg-gray-50">
                Trending
              </a>
            </Link>
            
            <Link href="/contact">
              <a className="block px-3 py-2 rounded-md text-base font-medium text-dark hover:text-primary hover:bg-gray-50">
                Kontak
              </a>
            </Link>
            
            {user ? (
              <div className="pt-4 pb-3 border-t border-gray-100">
                <>
                  {user.isAdmin && (
                    <Link href="/cd25-secure-admin-panel/dashboard">
                      <a className="block px-3 py-2 rounded-md text-base font-medium text-primary hover:bg-gray-50">
                        Dashboard
                      </a>
                    </Link>
                  )}
                  <Button 
                    variant="ghost" 
                    className="w-full justify-start px-3 py-2 text-base font-medium text-primary"
                    onClick={() => logoutMutation.mutate()}
                  >
                    Logout
                  </Button>
                </>
              </div>
            ) : null}
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;

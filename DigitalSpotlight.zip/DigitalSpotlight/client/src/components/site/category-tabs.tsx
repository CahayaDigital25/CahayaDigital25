import { FC, useRef } from "react";
import { Link, useRoute } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Category } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";

interface CategoryTabsProps {
  selectedCategory?: string;
}

export const CategoryTabs: FC<CategoryTabsProps> = ({ selectedCategory }) => {
  const [isHome] = useRoute("/");
  
  const { data: categories, isLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  if (isLoading) {
    return (
      <section className="bg-light py-4 border-b border-light-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollArea className="w-full whitespace-nowrap">
            <div className="flex space-x-4">
              <Skeleton className="h-9 w-16 rounded-full" />
              <Skeleton className="h-9 w-20 rounded-full" />
              <Skeleton className="h-9 w-24 rounded-full" />
              <Skeleton className="h-9 w-28 rounded-full" />
              <Skeleton className="h-9 w-20 rounded-full" />
              <Skeleton className="h-9 w-16 rounded-full" />
            </div>
            <ScrollBar orientation="horizontal" />
          </ScrollArea>
        </div>
      </section>
    );
  }

  return (
    <section className="bg-light py-4 border-b border-light-gray">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <ScrollArea className="w-full whitespace-nowrap">
          <div className="flex space-x-4 pb-2">
            <Link href="/">
              <a>
                <Button 
                  variant={(!selectedCategory && isHome) ? "default" : "outline"}
                  className="rounded-full"
                  size="sm"
                >
                  Semua
                </Button>
              </a>
            </Link>
            
            {categories?.map((category) => (
              <Link key={category.id} href={`/category/${category.slug}`}>
                <a>
                  <Button
                    variant={selectedCategory === category.slug ? "default" : "outline"}
                    className="rounded-full"
                    size="sm"
                  >
                    {category.name}
                  </Button>
                </a>
              </Link>
            ))}
          </div>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>
      </div>
    </section>
  );
};

export default CategoryTabs;


import { FC } from "react";
import { Link } from "wouter";

interface LogoProps {
  withText?: boolean;
  textColor?: string;
  size?: "small" | "medium" | "large";
}

export const Logo: FC<LogoProps> = ({ 
  withText = true, 
  textColor = "text-primary", 
  size = "medium" 
}) => {
  const getLogoSize = () => {
    switch (size) {
      case "small":
        return "w-10 h-10";
      case "large":
        return "w-14 h-14";
      case "medium":
      default:
        return "w-12 h-12";
    }
  };

  const getTextSize = () => {
    switch (size) {
      case "small":
        return "text-lg";
      case "large":
        return "text-2xl";
      case "medium":
      default:
        return "text-xl";
    }
  };

  return (
    <Link href="/">
      <a className="flex items-center gap-3 cursor-pointer">
        <div className={`${getLogoSize()} bg-gradient-to-br from-blue-600 to-blue-800 rounded-lg flex items-center justify-center shadow-lg transform hover:scale-105 transition-transform duration-200`}>
          <div className="text-white font-bold flex flex-col items-center justify-center leading-none">
            <span className="text-sm">CD</span>
            <span className="text-[10px]">25</span>
          </div>
        </div>
        {withText && (
          <span className={`${getTextSize()} font-montserrat font-bold ${textColor} tracking-tight`}>
            Cahaya<span className="text-blue-600">Digital</span>
            <span className="text-accent">25</span>
          </span>
        )}
      </a>
    </Link>
  );
};

export default Logo;

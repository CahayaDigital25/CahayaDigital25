
import { FC } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { ArticleWithCategory } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Calendar } from "lucide-react";
import { format } from "date-fns";

const HeroSkeleton: FC = () => (
  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
    <div className="md:col-span-2">
      <Skeleton className="h-[500px] w-full rounded-2xl" />
    </div>
    <div className="space-y-6">
      <Skeleton className="h-[240px] w-full rounded-2xl" />
      <Skeleton className="h-[240px] w-full rounded-2xl" />
    </div>
  </div>
);

export const HeroSection: FC = () => {
  const { data: featuredArticles, isLoading } = useQuery<ArticleWithCategory[]>({
    queryKey: ["/api/articles", { featured: true }],
  });

  if (isLoading) {
    return (
      <section className="bg-gradient-to-b from-blue-50 to-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <HeroSkeleton />
        </div>
      </section>
    );
  }

  if (!featuredArticles || featuredArticles.length === 0) {
    return null;
  }

  const mainArticle = featuredArticles[0];
  const secondaryArticles = featuredArticles.slice(1, 3);

  return (
    <section className="bg-gradient-to-b from-blue-50 to-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Link href={`/article/${mainArticle.slug}`} className="md:col-span-2">
            <Card className="group overflow-hidden rounded-2xl transition-transform hover:scale-[1.02] duration-300 h-[500px] relative">
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent z-10" />
              <img
                src={mainArticle.imageUrl || '/placeholder.jpg'}
                alt={mainArticle.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-0 left-0 right-0 p-8 z-20 text-white">
                <div className="space-y-4">
                  <Badge className="bg-blue-600 hover:bg-blue-700">
                    {mainArticle.category?.name}
                  </Badge>
                  <h2 className="text-3xl font-bold font-montserrat group-hover:text-blue-300 transition-colors">
                    {mainArticle.title}
                  </h2>
                  <div className="flex items-center text-sm text-gray-300">
                    <Calendar className="h-4 w-4 mr-1" />
                    <time dateTime={mainArticle.publishedAt}>
                      {format(new Date(mainArticle.publishedAt), 'dd MMMM yyyy')}
                    </time>
                  </div>
                </div>
              </div>
            </Card>
          </Link>
          
          <div className="space-y-6">
            {secondaryArticles.map((article) => (
              <Link key={article.id} href={`/article/${article.slug}`}>
                <Card className="group overflow-hidden rounded-2xl transition-transform hover:scale-[1.02] duration-300 h-[240px] relative">
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent z-10" />
                  <img
                    src={article.imageUrl || '/placeholder.jpg'}
                    alt={article.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute bottom-0 left-0 right-0 p-6 z-20 text-white">
                    <div className="space-y-3">
                      <Badge className="bg-blue-600 hover:bg-blue-700">
                        {article.category?.name}
                      </Badge>
                      <h3 className="text-xl font-bold font-montserrat group-hover:text-blue-300 transition-colors">
                        {article.title}
                      </h3>
                    </div>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;

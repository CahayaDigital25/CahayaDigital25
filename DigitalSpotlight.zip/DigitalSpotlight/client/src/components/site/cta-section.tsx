import { FC } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export const CTASection: FC = () => {
  return (
    <section className="bg-primary py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-3xl font-montserrat font-bold text-white mb-4">
          Ingin Berkolaborasi dengan Kami?
        </h2>
        <p className="text-white/80 text-lg mb-8 max-w-2xl mx-auto">
          Kami selalu terbuka untuk kolaborasi dengan pakar teknologi, penulis, dan pemimpin pemikiran di industri digital.
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-4 max-w-md mx-auto">
          <Link href="/contact">
            <Button
              variant="outline" 
              className="bg-white text-primary hover:bg-gray-100 rounded-full w-full sm:w-auto"
            >
              Hubungi Kami
            </Button>
          </Link>
          <Link href="/submit-article">
            <Button
              className="bg-accent hover:bg-accent/90 text-white rounded-full w-full sm:w-auto"
            >
              Kirim Artikel
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default CTASection;

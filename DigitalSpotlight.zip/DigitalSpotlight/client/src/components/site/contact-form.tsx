import { FC, useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";

export const ContactForm: FC = () => {
  const [isLoading, setIsLoading] = useState(false);
  
  // Google Form embed URL - in a real implementation, this would be replaced with an actual Google Form embed
  const googleFormUrl = "https://docs.google.com/forms/d/e/1FAIpQLSf9y3zxKCF0qz9MfSVCAfUl8OhNblFASL9LHhZMp1JdQQPx2g/viewform?embedded=true";
  
  return (
    <section id="contact" className="py-16 bg-light">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-montserrat font-bold text-dark mb-4">Hubungi Kami</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Punya pertanyaan, saran, atau ingin berkolaborasi? Isi formulir di bawah ini dan tim kami akan menghubungi Anda.
          </p>
        </div>
        
        <div className="max-w-3xl mx-auto">
          <Card>
            <CardContent className="p-6">
              <div className="aspect-w-16 aspect-h-9 min-h-[500px]">
                <iframe 
                  src={googleFormUrl}
                  width="100%" 
                  height="100%" 
                  className="border-0 w-full h-full"
                  frameBorder="0" 
                  marginHeight={0} 
                  marginWidth={0}
                  onLoad={() => setIsLoading(false)}
                >
                  Memuat...
                </iframe>
                
                {isLoading && (
                  <div className="absolute inset-0 flex items-center justify-center bg-white/80">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default ContactForm;

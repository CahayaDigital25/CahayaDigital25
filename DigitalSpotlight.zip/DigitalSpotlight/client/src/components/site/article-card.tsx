import { FC } from "react";
import { Link } from "wouter";
import { ArticleWithCategory } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { format } from "date-fns";
import { id } from "date-fns/locale";

interface ArticleCardProps {
  article: ArticleWithCategory;
}

export const ArticleCard: FC<ArticleCardProps> = ({ article }) => {
  return (
    <Card className="mb-8 overflow-hidden group hover:shadow-md transition-shadow duration-300">
      <div className="md:flex">
        <div className="md:flex-shrink-0 md:w-48 h-64 md:h-full relative">
          <img 
            className="h-48 md:h-full w-full md:w-48 object-cover" 
            src={article.imageUrl} 
            alt={article.title} 
          />
          <span className="absolute top-3 left-3 inline-block px-2 py-1 bg-primary text-white text-xs font-semibold rounded-full">
            {article.category?.name}
          </span>
        </div>
        <CardContent className="p-6 flex flex-col justify-between">
          <div>
            <Link href={`/article/${article.id}`}>
              <a className="block">
                <h3 className="text-xl font-montserrat font-bold mb-2 group-hover:text-primary transition-colors duration-300">
                  {article.title}
                </h3>
              </a>
            </Link>
            <p className="text-gray-600 mb-4 line-clamp-3">
              {article.summary}
            </p>
          </div>
          <div className="flex items-center text-sm text-gray-500">
            <span>{format(new Date(article.publishedAt), 'dd MMMM yyyy', { locale: id })}</span>
            <span className="mx-2">•</span>
            <span>{article.readTime} menit membaca</span>
          </div>
        </CardContent>
      </div>
    </Card>
  );
};

export default ArticleCard;

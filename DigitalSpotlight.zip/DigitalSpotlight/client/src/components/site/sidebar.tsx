import { FC } from "react";
import { Link } from "wouter";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

interface SidebarProps {
  onSearch?: (query: string) => void;
}

import { useQuery } from "@tanstack/react-query";
import type { ArticleWithCategory } from "@shared/schema";

export const Sidebar: FC<SidebarProps> = ({ onSearch }) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [email, setEmail] = useState("");
  const { toast } = useToast();

  const { data: trendingArticles } = useQuery<ArticleWithCategory[]>({
    queryKey: ["/api/articles", { featured: true }],
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSearch) {
      onSearch(searchQuery);
    }
  };

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      toast({
        title: "Berlangganan berhasil!",
        description: "Anda akan menerima newsletter kami secara berkala.",
      });
      setEmail("");
    }
  };

  return (
    <div className="space-y-6">
      {/* Search box */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-montserrat">Pencarian</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSearch} className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              type="text"
              placeholder="Cari berita..."
              className="pl-10 rounded-full"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </form>
        </CardContent>
      </Card>
      
      {/* Trending section */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-montserrat">Trending Topic</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {trendingArticles && trendingArticles.slice(0, 5).map((article, index) => (
            <div key={article.id} className="flex items-center gap-3">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center font-montserrat font-bold text-primary">
                #{index + 1}
              </div>
              <div>
                <Link href={`/article/${article.id}`}>
                  <a className="text-dark font-medium hover:text-primary line-clamp-2">
                    {article.title}
                  </a>
                </Link>
                <p className="text-sm text-gray-500">{article.category?.name}</p>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
      
      {/* Newsletter subscription */}
      <Card className="bg-primary text-white">
        <CardHeader>
          <CardTitle className="text-lg font-montserrat text-white">Berlangganan Newsletter</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-white/80 mb-4">Dapatkan update berita teknologi terbaru langsung ke email Anda</p>
          <form onSubmit={handleSubscribe} className="space-y-3">
            <Input
              type="email"
              placeholder="Alamat email Anda"
              className="bg-white text-dark rounded-full"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <Button type="submit" className="w-full bg-accent hover:bg-accent/90 text-white rounded-full">
              Berlangganan
            </Button>
          </form>
        </CardContent>
      </Card>
      
      {/* Social media links */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-montserrat">Ikuti Kami</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-3">
            <a href="#" className="w-10 h-10 bg-[#3b5998] text-white rounded-full flex items-center justify-center hover:opacity-90 transition-opacity">
              <i className="fab fa-facebook-f"></i>
            </a>
            <a href="#" className="w-10 h-10 bg-[#1da1f2] text-white rounded-full flex items-center justify-center hover:opacity-90 transition-opacity">
              <i className="fab fa-twitter"></i>
            </a>
            <a href="#" className="w-10 h-10 bg-[#c32aa3] text-white rounded-full flex items-center justify-center hover:opacity-90 transition-opacity">
              <i className="fab fa-instagram"></i>
            </a>
            <a href="#" className="w-10 h-10 bg-[#ff0000] text-white rounded-full flex items-center justify-center hover:opacity-90 transition-opacity">
              <i className="fab fa-youtube"></i>
            </a>
            <a href="#" className="w-10 h-10 bg-[#0a66c2] text-white rounded-full flex items-center justify-center hover:opacity-90 transition-opacity">
              <i className="fab fa-linkedin-in"></i>
            </a>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Sidebar;

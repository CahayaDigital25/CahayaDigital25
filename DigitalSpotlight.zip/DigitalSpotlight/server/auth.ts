import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser } from "@shared/schema";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

export async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

export function setupAuth(app: Express) {
  const sessionSecret = process.env.SESSION_SECRET || "cahayadigital25_secret_key";
  
  const sessionSettings: session.SessionOptions = {
    secret: sessionSecret,
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      maxAge: 1000 * 60 * 60 * 24, // 1 day
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
    }
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  // Passport strategy for authentication
  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        // Check for admin user with hard-coded credentials
        if (username === "admin") {
          const user = await storage.getUserByUsername("admin");
          
          // If admin user exists in storage, verify password
          if (user) {
            // Check if password is hashed
            if (user.password.includes('.')) {
              // Password is hashed, compare with hash
              const isValid = await comparePasswords(password, user.password);
              return isValid 
                ? done(null, user) 
                : done(null, false, { message: "Invalid username or password" });
            } else if (user.password === "admin123") {
              // Legacy non-hashed password, update it to hashed version
              const hashedPassword = await hashPassword("admin123");
              await storage.updateUser(user.id, { password: hashedPassword });
              
              // Update user object with new hashed password
              const updatedUser = { ...user, password: hashedPassword };
              return done(null, updatedUser);
            } else {
              return done(null, false, { message: "Invalid username or password" });
            }
          }
          
          // If admin doesn't exist, create it with hashed password
          if (password === "admin123") {
            const hashedPassword = await hashPassword("admin123");
            const newUser = await storage.createUser({
              username: "admin",
              password: hashedPassword,
              isAdmin: true
            });
            return done(null, newUser);
          } else {
            return done(null, false, { message: "Invalid username or password" });
          }
        }
        
        // For regular users
        const user = await storage.getUserByUsername(username);
        if (!user) {
          return done(null, false, { message: "Invalid username or password" });
        }
        
        // Check if password is stored as hash
        if (user.password.includes('.')) {
          const isValid = await comparePasswords(password, user.password);
          return isValid 
            ? done(null, user) 
            : done(null, false, { message: "Invalid username or password" });
        } else {
          // Legacy plain password comparison (should be rare)
          if (user.password === password) {
            // Update to hashed version for future logins
            const hashedPassword = await hashPassword(password);
            await storage.updateUser(user.id, { password: hashedPassword });
            
            // Update user object with new hashed password
            const updatedUser = { ...user, password: hashedPassword };
            return done(null, updatedUser);
          } else {
            return done(null, false, { message: "Invalid username or password" });
          }
        }
      } catch (error) {
        return done(error);
      }
    })
  );

  passport.serializeUser((user, done) => {
    done(null, user.id);
  });
  
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  // API Routes for authentication
  app.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err, user, info) => {
      if (err) return next(err);
      if (!user) {
        return res.status(401).json({ message: info?.message || "Authentication failed" });
      }
      req.login(user, (err) => {
        if (err) return next(err);
        return res.status(200).json(user);
      });
    })(req, res, next);
  });

  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    res.json(req.user);
  });
  
  // Middleware to check if user is admin
  app.use("/api/admin/*", (req, res, next) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Forbidden: Admin access required" });
    }
    next();
  });
}

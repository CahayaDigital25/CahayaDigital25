import { users, type User, type InsertUser, articles, type Article, type InsertArticle, categories, type Category, type InsertCategory } from "@shared/schema";
import createMemoryStore from "memorystore";
import session from "express-session";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUsers(): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  
  // Category operations
  getCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: number, category: Partial<InsertCategory>): Promise<Category | undefined>;
  deleteCategory(id: number): Promise<boolean>;
  
  // Article operations
  getArticles(): Promise<Article[]>;
  getArticle(id: number): Promise<Article | undefined>;
  getArticlesByCategory(categoryId: number): Promise<Article[]>;
  getFeaturedArticles(): Promise<Article[]>;
  createArticle(article: InsertArticle): Promise<Article>;
  updateArticle(id: number, article: Partial<InsertArticle>): Promise<Article | undefined>;
  deleteArticle(id: number): Promise<boolean>;
  
  // Session store
  sessionStore: any; // Using any for session store to avoid type issues
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private categories: Map<number, Category>;
  private articles: Map<number, Article>;
  private userId: number = 1;
  private categoryId: number = 1;
  private articleId: number = 1;
  sessionStore: session.SessionStore;
  
  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.articles = new Map();
    
    // Initialize with admin user
    this.createUser({
      username: "admin",
      password: "admin123",
      isAdmin: true,
    });
    
    // Initialize with some categories
    const categories = [
      { name: "Teknologi", slug: "teknologi" },
      { name: "Gadget", slug: "gadget" },
      { name: "Bisnis Digital", slug: "bisnis-digital" },
      { name: "Game", slug: "game" },
      { name: "Startup", slug: "startup" },
      { name: "Aplikasi", slug: "aplikasi" },
      { name: "Fintech", slug: "fintech" },
    ];
    
    for (const category of categories) {
      this.createCategory(category);
    }
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    });
  }
  
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }
  
  async getUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }
  
  async createUser(user: InsertUser): Promise<User> {
    const id = this.userId++;
    const newUser: User = { 
      ...user, 
      id, 
      isAdmin: user.isAdmin !== undefined ? user.isAdmin : false 
    };
    this.users.set(id, newUser);
    return newUser;
  }
  
  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const existingUser = this.users.get(id);
    if (!existingUser) return undefined;
    
    const updatedUser: User = { ...existingUser, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async deleteUser(id: number): Promise<boolean> {
    return this.users.delete(id);
  }
  
  // Category methods
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }
  
  async getCategory(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }
  
  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    return Array.from(this.categories.values()).find(category => category.slug === slug);
  }
  
  async createCategory(category: InsertCategory): Promise<Category> {
    const id = this.categoryId++;
    const newCategory: Category = { ...category, id };
    this.categories.set(id, newCategory);
    return newCategory;
  }
  
  async updateCategory(id: number, category: Partial<InsertCategory>): Promise<Category | undefined> {
    const existingCategory = this.categories.get(id);
    if (!existingCategory) return undefined;
    
    const updatedCategory: Category = { ...existingCategory, ...category };
    this.categories.set(id, updatedCategory);
    return updatedCategory;
  }
  
  async deleteCategory(id: number): Promise<boolean> {
    return this.categories.delete(id);
  }
  
  // Article methods
  async getArticles(): Promise<Article[]> {
    return Array.from(this.articles.values()).sort((a, b) => {
      return new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime();
    });
  }
  
  async getArticle(id: number): Promise<Article | undefined> {
    return this.articles.get(id);
  }
  
  async getArticlesByCategory(categoryId: number): Promise<Article[]> {
    return Array.from(this.articles.values())
      .filter(article => article.categoryId === categoryId)
      .sort((a, b) => {
        return new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime();
      });
  }
  
  async getFeaturedArticles(): Promise<Article[]> {
    return Array.from(this.articles.values())
      .filter(article => article.featured)
      .sort((a, b) => {
        return new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime();
      });
  }
  
  async createArticle(article: InsertArticle): Promise<Article> {
    const id = this.articleId++;
    
    // Pastikan featured adalah boolean
    const featured = typeof article.featured === 'boolean' 
      ? article.featured 
      : false;
    
    // Pastikan publishedAt adalah Date
    const publishedAt = article.publishedAt instanceof Date 
      ? article.publishedAt 
      : new Date(article.publishedAt);
    
    // Buat artikel baru dengan format yang tepat
    const newArticle: Article = {
      id,
      title: article.title,
      content: article.content,
      summary: article.summary,
      imageUrl: article.imageUrl,
      categoryId: article.categoryId,
      publishedAt,
      readTime: article.readTime,
      featured
    };
    
    this.articles.set(id, newArticle);
    return newArticle;
  }
  
  async updateArticle(id: number, article: Partial<InsertArticle>): Promise<Article | undefined> {
    const existingArticle = this.articles.get(id);
    if (!existingArticle) return undefined;
    
    // Buat objek pembaruan dengan format yang tepat
    const updateData: Partial<Article> = {};
    
    // Salin properti yang ada di article
    if (article.title !== undefined) updateData.title = article.title;
    if (article.content !== undefined) updateData.content = article.content;
    if (article.summary !== undefined) updateData.summary = article.summary;
    if (article.imageUrl !== undefined) updateData.imageUrl = article.imageUrl;
    if (article.categoryId !== undefined) updateData.categoryId = Number(article.categoryId);
    if (article.readTime !== undefined) updateData.readTime = Number(article.readTime);
    if (article.featured !== undefined) updateData.featured = Boolean(article.featured);
    
    // Khusus untuk publishedAt, pastikan formatnya Date
    if (article.publishedAt !== undefined) {
      updateData.publishedAt = article.publishedAt instanceof Date 
        ? article.publishedAt 
        : new Date(article.publishedAt);
    }
    
    const updatedArticle: Article = { ...existingArticle, ...updateData };
    this.articles.set(id, updatedArticle);
    return updatedArticle;
  }
  
  async deleteArticle(id: number): Promise<boolean> {
    return this.articles.delete(id);
  }
}

export const storage = new MemStorage();
